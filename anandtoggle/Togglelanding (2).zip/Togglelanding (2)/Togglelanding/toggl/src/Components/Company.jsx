import React from "react";
import booking from "./Images/Booking.jpg";
import "./Company.css";

function Company() {
  return (
    <div className="companylogos">{/* <img src={booking} alt="" /> */}</div>
  );
}

export default Company;
